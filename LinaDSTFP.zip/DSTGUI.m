%% DST Final Project | Fall, 2016 | Lina Borda | N17477409
% 
%   This function presents the user with various alternatives to create
%   hybrid instruments by convolution, using percussive instrument sounds 
%   as the impulse, and melodic instrument sounds as the resonance. 
%   The new instruments can then be played in combination and saved as 
%   audiofiles.
%
%   Inputs: irFilename:name of .wav file that contains the impulse response
%           sigFilename:name of .wav file that contains a signal
%           outFile:name of .wav file to which the new convolved signal 
%                   will be written



function varargout = DSTGUI(varargin)
% DSTGUI MATLAB code for DSTGUI.fig
%      DSTGUI, by itself, creates a new DSTGUI or raises the existing
%      singleton*.
%
%      H = DSTGUI returns the handle to a new DSTGUI or the handle to
%      the existing singleton*.
%
%      DSTGUI('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in DSTGUI.M with the given input arguments.
%
%      DSTGUI('Property','Value',...) creates a new DSTGUI or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before DSTGUI_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to DSTGUI_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help DSTGUI

% Last Modified by GUIDE v2.5 19-Dec-2016 22:19:25

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @DSTGUI_OpeningFcn, ...
                   'gui_OutputFcn',  @DSTGUI_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before DSTGUI is made visible.
function DSTGUI_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to DSTGUI (see VARARGIN)


% LINA'S NOTES:

% The sampling rate will be the same for all instances of the audio created,
% therefore the handles object will hold it for the entire function
% Using the handles object, initial values for x (sigFilename) and 
% h (irFilename) are created to then be chosen from the GUI.

handles.fs = 44100;
handles.x = 'gypsyviolin1.wav';
handles.h = 'tambourine.wav';

% Choose default command line output for DSTGUI
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes DSTGUI wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = DSTGUI_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes on selection change in Full.
function Full_Callback(hObject, eventdata, handles)
% hObject    handle to Full (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns Full contents as cell array
%        contents{get(hObject,'Value')} returns selected item from Full

% LINA'S NOTES:

handles.output = hObject;
guidata(hObject, handles);


% --- Executes during object creation, after setting all properties.
function Full_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Full (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: listbox controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on selection change in popupmenu1.
function popupmenu1_Callback(hObject, eventdata, handles)
% hObject    handle to popupmenu1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns popupmenu1 contents as cell array
%        contents{get(hObject,'Value')} returns selected item from popupmenu1

% LINA'S NOTES:

%Section/Shape of convolution

%w = conv(x, h, shape);

contents = cellstr(get(hObject,'String'));
popmenu1 = contents{get(hObject,'Value')};

if (strcmp (popmenu1, 'full')); 
    popmenu1 = 1;
%w = conv(x, h, full);
%full: default convolution
elseif (strcmp (popmenu1, 'same')); 
    popmenu1 = 2;
%w = conv (x, h, same);
%same: central part of the convolution, same size as x
elseif (strcmp (popmenu1, 'valid'));
    popmenu1 = 3;
%w = conv(x, h, valid);
%valid: parts of the convolution that are computed without the zero-padded edges
end 

handles.output = hObject;
guidata(hObject, handles);

% --- Executes on selection change in popupmenu2.
function popupmenu2_Callback(hObject, eventdata, handles)
% hObject    handle to popupmenu2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns popupmenu2 contents as cell array
%        contents{get(hObject,'Value')} returns selected item from popupmenu2

% LINA'S NOTES:

%Resonance instruments (sigFilename) to choose from

contents = cellstr(get(hObject,'String'));
popmenu2 = contents{get(hObject,'Value')};

%sigFilename
if (strcmp (popmenu2, 'gypsyviolin1.wav')); 
    popmenu2 = 1;
    %choice of gypsyviolin1
elseif (strcmp (popmenu2, 'gypsyviolin2.wav')); 
    popmenu2 = 2;
    %choice of gypsyviolin2   
elseif (strcmp (popmenu2, 'balkanflute.wav')); 
    popmenu2 = 3;
    %choice of balkanflute 
elseif (strcmp (popmenu2, 'chineseflute.wav')); 
    popmenu2 = 4;
    %choice of chineseflute  
elseif (strcmp (popmenu2, 'duduk.wav')); 
    popmenu2 = 5;
    %choice of duduk.wav
end

handles.output = hObject;
guidata(hObject, handles);


% --- Executes during object creation, after setting all properties.
function popupmenu2_CreateFcn(hObject, eventdata, handles)
% hObject    handle to popupmenu2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on selection change in popupmenu3.
function popupmenu3_Callback(hObject, eventdata, handles)
% hObject    handle to popupmenu3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns popupmenu3 contents as cell array
%        contents{get(hObject,'Value')} returns selected item from popupmenu3

% LINA'S NOTES:

%Impulse instrument(irFilename) to choose from

contents = cellstr(get(hObject,'String'));
popmenu3 = contents{get(hObject,'Value')};

%irFilename 
if (strcmp (popmenu3, 'tambourine.wav')); 
    popmenu3 = 1;
    %choice of tambourine
elseif (strcmp (popmenu3, 'gong.wav')); 
    popmenu3 = 2;
    %choice of gong  
elseif (strcmp (popmenu3, 'concertbassdrum.wav')); 
    popmenu3 = 3;
    %choice of concert bass drum 
elseif (strcmp (popmenu3, 'chimes.wav')); 
    popmenu3 = 4;
    %choice of chimes  
elseif (strcmp (popmenu3, 'cymbal.wav')); 
    popmenu3 = 5;
    %choice of cymbal
end

handles.output = hObject;
guidata(hObject, handles);


% --- Executes during object creation, after setting all properties.
function popupmenu3_CreateFcn(hObject, eventdata, handles)
% hObject    handle to popupmenu3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in pushbutton1.
function pushbutton1_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

%LINA'S NOTES:

handles.output = hObject;
guidata(hObject, handles);

sigFilename = handles.x;
irFilename = handles.h;

%First step: convolve one resonance with one impulse

%Resonance instrument
[x, fs]= audioread ('gypsyviolin1.wav');
x = mean (x, 2); %Force .wav audiofile to mono

%Create a time vector to match the length of the signal
dur = length(x) / fs;
t = 0:1/fs:dur-1/fs;

%Impulse instrument
[h, fs]= audioread ('tambourine.wav');
h = mean (h, 2); %Force .wav audiofile to mono

%Create a time vector to match the length of the signal
dur = length(h) / fs;
t = 0:1/fs:dur-1/fs;

w = conv (x, h);
soundsc(w, fs);


% --- Executes during object creation, after setting all properties.
function axes1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to axes1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: place code in OpeningFcn to populate axes1

% LINA'S NOTES:

% Plots the waveform of the hybrid instrument sound

plot(w, 'r');


% --- Executes on button press in pushbutton3.
function pushbutton3_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% LINA'S NOTES:

% Saves new hybrid instrument as audiofile

% audiowrite